import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  TextInput, Animated, StatusBar, KeyboardAvoidingView,
  Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/color';
import api from '../services/api';
import useAuthStore from '../store/useAuthStore';

export default function ChatRoomScreen({ route, navigation }) {
  const { chatId, playerName } = route.params || {};
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [typing, setTyping] = useState(false);
  const flatListRef = useRef(null);
  const headerAnim = useRef(new Animated.Value(0)).current;
  const inputAnim = useRef(new Animated.Value(0)).current;
  const { user } = useAuthStore();

  useEffect(() => {
    fetchMessages();
    Animated.parallel([
      Animated.timing(headerAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.timing(inputAnim, { toValue: 1, duration: 500, delay: 200, useNativeDriver: true }),
    ]).start();
  }, []);

  const fetchMessages = async () => {
    try {
      const res = await api.get(`/chats/${chatId}/messages`);
      if (res.data.success) setMessages(res.data.messages);
    } catch (err) {
      console.log('msgs error:', err.message);
    }
  };

  const sendMessage = async () => {
    if (!text.trim()) return;
    const tempMsg = {
      id: Date.now().toString(),
      ciphertext: text,
      sender_id: user?.id,
      created_at: new Date().toISOString(),
      temp: true,
    };
    setMessages(prev => [...prev, tempMsg]);
    setText('');
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const formatTime = (ts) => {
    if (!ts) return '';
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const MessageBubble = ({ item, index }) => {
    const isMe = item.sender_id === user?.id;
    const slideAnim = useRef(new Animated.Value(isMe ? 40 : -40)).current;
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 300, delay: index * 30, useNativeDriver: true }),
        Animated.spring(slideAnim, { toValue: 0, friction: 8, delay: index * 30, useNativeDriver: true }),
      ]).start();
    }, []);

    return (
      <Animated.View style={[
        styles.msgWrapper,
        isMe ? styles.msgWrapperMe : styles.msgWrapperThem,
        { opacity: fadeAnim, transform: [{ translateX: slideAnim }] }
      ]}>
        {!isMe && (
          <View style={styles.msgAvatar}>
            <Text style={styles.msgAvatarText}>
              {playerName?.slice(0, 2) || '??'}
            </Text>
          </View>
        )}
        <View style={styles.bubbleContainer}>
          {isMe ? (
            <LinearGradient
              colors={[colors.neonGreen + 'CC', colors.neonPurple + 'AA']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              style={[styles.bubble, styles.bubbleMe]}
            >
              <Text style={styles.bubbleTextMe}>{item.ciphertext}</Text>
              <View style={styles.msgMeta}>
                <Text style={styles.msgTime}>{formatTime(item.created_at)}</Text>
                <Ionicons name="checkmark-done" size={12} color="#00000080" />
              </View>
            </LinearGradient>
          ) : (
            <View style={[styles.bubble, styles.bubbleThem]}>
              <View style={styles.lockRow}>
                <Ionicons name="lock-closed" size={9} color={colors.neonGreen} />
                <Text style={styles.encLabel}> E2E</Text>
              </View>
              <Text style={styles.bubbleTextThem}>{item.ciphertext}</Text>
              <Text style={styles.msgTimeThem}>{formatTime(item.created_at)}</Text>
            </View>
          )}
        </View>
      </Animated.View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <StatusBar barStyle="light-content" backgroundColor="#0D0D0D" />

      {/* Top line */}
      <LinearGradient
        colors={[colors.neonGreen, colors.neonPurple, 'transparent']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={styles.topLine}
      />

      {/* Header */}
      <Animated.View style={[styles.header, {
        opacity: headerAnim,
        transform: [{ translateY: headerAnim.interpolate({ inputRange: [0, 1], outputRange: [-20, 0] }) }]
      }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={22} color={colors.neonGreen} />
        </TouchableOpacity>

        <View style={styles.headerCenter}>
          <LinearGradient
            colors={[colors.neonGreen + '80', colors.neonPurple + '80']}
            style={styles.headerAvatar}
          >
            <View style={styles.headerAvatarInner}>
              <Text style={styles.headerAvatarText}>
                {playerName?.slice(0, 2) || '??'}
              </Text>
            </View>
          </LinearGradient>
          <View>
            <Text style={styles.headerName}>{playerName || 'PLAYER_????'}</Text>
            <View style={styles.onlineRow}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>ONLINE</Text>
            </View>
          </View>
        </View>

        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconBtn}>
            <Ionicons name="call-outline" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn}>
            <Ionicons name="ellipsis-vertical" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>
      </Animated.View>

      {/* Divider */}
      <LinearGradient
        colors={[colors.neonGreen + '40', 'transparent']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={styles.divider}
      />

      {/* Messages */}
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.msgList}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        ListEmptyComponent={() => (
          <View style={styles.emptyChat}>
            <Ionicons name="shield-checkmark-outline" size={48} color={colors.textMuted} />
            <Text style={styles.emptyChatText}>CHANNEL SECURED</Text>
            <Text style={styles.emptyChatSub}>Messages are end-to-end encrypted</Text>
          </View>
        )}
        renderItem={({ item, index }) => (
          <MessageBubble item={item} index={index} />
        )}
      />

      {/* Typing indicator */}
      {typing && (
        <View style={styles.typingContainer}>
          <Text style={styles.typingText}>PLAYER is typing</Text>
          <View style={styles.typingDots}>
            {[0, 1, 2].map(i => (
              <View key={i} style={styles.typingDot} />
            ))}
          </View>
        </View>
      )}

      {/* Input Bar */}
      <Animated.View style={[styles.inputBar, {
        opacity: inputAnim,
        transform: [{ translateY: inputAnim.interpolate({ inputRange: [0, 1], outputRange: [40, 0] }) }]
      }]}>
        <TouchableOpacity style={styles.attachBtn}>
          <Ionicons name="attach" size={22} color={colors.textSecondary} />
        </TouchableOpacity>

        <View style={styles.inputWrap}>
          <LinearGradient
            colors={[colors.neonGreen + '10', colors.neonPurple + '10']}
            style={StyleSheet.absoluteFill}
          />
          <TextInput
            style={styles.input}
            placeholder="Type a message..."
            placeholderTextColor={colors.textMuted}
            value={text}
            onChangeText={setText}
            multiline
            maxLength={500}
          />
        </View>

        <TouchableOpacity
          style={[styles.sendBtn, text.trim().length > 0 && styles.sendBtnActive]}
          onPress={sendMessage}
          activeOpacity={0.8}
        >
          {text.trim().length > 0 ? (
            <LinearGradient
              colors={[colors.neonGreen, colors.neonPurple]}
              style={styles.sendGradient}
            >
              <Ionicons name="send" size={18} color="#000" />
            </LinearGradient>
          ) : (
            <View style={styles.sendGradient}>
              <Ionicons name="mic-outline" size={18} color={colors.textSecondary} />
            </View>
          )}
        </TouchableOpacity>
      </Animated.View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D0D0D' },
  topLine: { height: 2 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingTop: 14,
    paddingBottom: 10,
  },
  backBtn: {
    padding: 8, borderRadius: 8,
    backgroundColor: '#1A1A1A', marginRight: 8,
  },
  headerCenter: {
    flex: 1, flexDirection: 'row',
    alignItems: 'center', gap: 10,
  },
  headerAvatar: {
    width: 42, height: 42, borderRadius: 21,
    padding: 2, justifyContent: 'center', alignItems: 'center',
  },
  headerAvatarInner: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: '#1A1A2E',
    justifyContent: 'center', alignItems: 'center',
  },
  headerAvatarText: {
    color: '#00FFB2',
    fontFamily: 'Orbitron_400Regular',
    fontSize: 10,
  },
  headerName: {
    color: '#FFFFFF',
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 16, letterSpacing: 2,
  },
  onlineRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#00FFB2' },
  onlineText: {
    color: '#00FFB2', fontSize: 10,
    fontFamily: 'Rajdhani_600SemiBold', letterSpacing: 2,
  },
  headerActions: { flexDirection: 'row', gap: 4 },
  iconBtn: {
    padding: 8, borderRadius: 8, backgroundColor: '#1A1A1A', marginLeft: 4,
  },

  divider: { height: 1, marginBottom: 4 },

  msgList: { padding: 16, paddingBottom: 8 },

  msgWrapper: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-end',
  },
  msgWrapperMe: { justifyContent: 'flex-end' },
  msgWrapperThem: { justifyContent: 'flex-start' },

  msgAvatar: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: '#1A1A2E',
    borderWidth: 1, borderColor: '#00FFB240',
    justifyContent: 'center', alignItems: 'center',
    marginRight: 8,
  },
  msgAvatarText: {
    color: '#00FFB2', fontSize: 9,
    fontFamily: 'Orbitron_400Regular',
  },

  bubbleContainer: { maxWidth: '75%' },
  bubble: {
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  bubbleMe: { borderBottomRightRadius: 4 },
  bubbleThem: {
    backgroundColor: '#1A1A2E',
    borderWidth: 1, borderColor: '#00FFB220',
    borderBottomLeftRadius: 4,
  },

  lockRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  encLabel: {
    color: '#00FFB2', fontSize: 9,
    fontFamily: 'Orbitron_400Regular', letterSpacing: 1,
  },

  bubbleTextMe: {
    color: '#000000',
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 15,
  },
  bubbleTextThem: {
    color: '#F0F0F0',
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 15,
  },
  msgMeta: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'flex-end', gap: 4, marginTop: 4,
  },
  msgTime: { color: '#00000080', fontSize: 10 },
  msgTimeThem: { color: '#444444', fontSize: 10, marginTop: 4, textAlign: 'right' },

  emptyChat: {
    flex: 1, alignItems: 'center',
    justifyContent: 'center', paddingTop: 80, gap: 8,
  },
  emptyChatText: {
    color: '#888888', fontFamily: 'Orbitron_700Bold',
    fontSize: 14, letterSpacing: 3,
  },
  emptyChatSub: {
    color: '#444444', fontFamily: 'Rajdhani_400Regular',
    fontSize: 13, letterSpacing: 1,
  },

  typingContainer: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingBottom: 4, gap: 8,
  },
  typingText: {
    color: '#00FFB2', fontSize: 11,
    fontFamily: 'Rajdhani_400Regular',
  },
  typingDots: { flexDirection: 'row', gap: 3 },
  typingDot: {
    width: 4, height: 4, borderRadius: 2,
    backgroundColor: '#00FFB2',
  },

  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 12,
    paddingVertical: 10,
    paddingBottom: 16,
    borderTopWidth: 1,
    borderTopColor: '#1A1A1A',
    gap: 8,
  },
  attachBtn: {
    padding: 10, borderRadius: 8,
    backgroundColor: '#1A1A1A',
  },
  inputWrap: {
    flex: 1, borderRadius: 20,
    borderWidth: 1, borderColor: '#00FFB230',
    paddingHorizontal: 14, paddingVertical: 10,
    overflow: 'hidden', maxHeight: 100,
  },
  input: {
    color: '#F0F0F0',
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 15, paddingVertical: 0,
  },
  sendBtn: {
    borderRadius: 22, overflow: 'hidden',
  },
  sendBtnActive: {
    shadowColor: '#00FFB2',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8, shadowRadius: 8, elevation: 6,
  },
  sendGradient: {
    width: 44, height: 44,
    justifyContent: 'center', alignItems: 'center',
    backgroundColor: '#1A1A1A',
    borderRadius: 22,
  },
});